//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Neko95.rc
//

#ifndef IDC_STATIC
#define IDC_STATIC				-1
#endif

#define IDI_AWAKE                       101
#define ID_SETTINGS                     101
#define IDI_UP1                         102
#define ID_EXIT                         102
#define IDI_UP2                         103
#define ID_TIMER_NEKOUPDATE             103
#define IDI_UPRIGHT1                    104
#define ID_TIMER_NEKO                   104
#define IDI_UPRIGHT2                    105
#define IDI_RIGHT1                      106
#define IDI_RIGHT2                      107
#define IDI_DOWNRIGHT1                  108
#define IDI_DOWNRIGHT2                  109
#define IDI_DOWN1                       110
#define IDI_DOWN2                       111
#define IDI_DOWNLEFT1                   112
#define IDI_DOWNLEFT2                   113
#define IDI_LEFT1                       114
#define IDI_LEFT2                       115
#define IDI_UPLEFT1                     116
#define IDI_UPLEFT2                     117
#define IDI_UPCLAW1                     118
#define IDI_UPCLAW2                     119
#define IDI_RIGHTCLAW1                  120
#define IDI_RIGHTCLAW2                  121
#define IDI_LEFTCLAW1                   122
#define IDI_LEFTCLAW2                   123
#define IDI_DOWNCLAW1                   124
#define IDI_DOWNCLAW2                   125
#define IDI_WASH2                       126
#define IDI_SCRATCH1                    127
#define IDI_SCRATCH2                    128
#define IDI_YAWN2                       129
#define IDI_YAWN3                       130
#define IDI_SLEEP1                      131
#define IDI_SLEEP2                      132

#define IDI_FP_UP		133
#define IDI_FP_UPRIGHT		134
#define IDI_FP_RIGHT		135
#define IDI_FP_DOWNRIGHT	136
#define IDI_FP_DOWN		137
#define IDI_FP_DOWNLEFT		138
#define IDI_FP_LEFT		139
#define IDI_FP_UPLEFT		140


// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        141
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           105
#endif
#endif
